第四章 线性时不变系统的代数结构分析

### 一、单项选择题

**1. 已知二阶系统 ![题图](images/image_001.png) 的初态和自由运动的两组值为**
![题图](images/image_002.png)
![题图](images/image_003.png)
![题图](images/image_004.png)
![题图](images/image_005.png)
则系统的状态系数矩阵A为( ).

- A.![选项图](images/image_006.png)
- B.![选项图](images/image_007.png)
- C.![选项图](images/image_008.png)
- D.![选项图](images/image_009.png)
- **答案：** B
- **解析：**
  二阶系统的状态运动表达式为: x(t)=Φ(t)x(0), 则状态转移矩阵为:
  ![解析图](images/image_010.png)
  故系统状态矩阵为:
  ![解析图](images/image_011.png)
  因此本题选B.

**2. 系统的传递函数是**
![题图](images/image_012.png)
则使系统状态完全能控能观的参数a的取值为( ).

- A. a≠1且a≠2且a≠3
- B. a≠1或a≠2或a≠3
- C. a=1且a=2且a=3
- D. a=1或a=2或a=3
- **答案：** A
- **解析：**
  系统的微分方程为y(···)+6y(··)+11y(·)+6y=x(·)+ax, 故其状态空间表达式为:
  ![解析图](images/image_013.png)
  y=[a 1 0]x
  能控性判别矩阵满秩, 系统完全能控; 能观性判别矩阵满秩, 系统完全能观. 故|$Q_{o}$|=-6(a+1)(a+2)(a+3)≠0, 即a≠1且a≠2且a≠3, 该系统完全能控能观.
  ![解析图](images/image_014.png)
  ![解析图](images/image_015.png)

**3. 有一个三阶的三输入系统**
![题图](images/image_016.png)
需要几个采样周期, 可以使系统从初始状态转移到原点( ).

- A. 1个
- B. 2个
- C. 3个
- **答案：** C
- **解析：** 系统完全可控, 答案为C.

**4. 已知系统 ![题图](images/image_017.png) 能控不能观, 则其对偶系统 ![题图](images/image_018.png) ( ).**

- A. 能控能观
- B. 能控不能观
- C. 能观不能控
- D. 不能控不能观
- **答案：** C
- **解析：**
  给定系统和对偶系统在能控性和能观性上具有对偶性, 给定系统的完全能控等价于对偶系统的完全能观, 给定系统的完全能观性等价于对偶系统的完全能控. 本题中, 给定系统能控不能观, 因此对偶系统是能观不能控的, 故应选择C项.
  二、解答题

**1. 某太阳能加热系统的微分方程为:**
![题图](images/image_019.png)
(1)请列写出系统的状态方程.
(2)当$u_{1} = 0, u_{2}$=1, d=1, 试求系统初始状态为零时的系统响应.
![题图](images/image_020.png)
答: 由题可知
![题图](images/image_021.png)
![题图](images/image_022.png)
![题图](images/image_023.png)
(1)系统状态方程为
![题图](images/image_024.png)
(2)由(1)知系统状态转移矩阵为:
![题图](images/image_025.png)
初始条件为, 且已知.
![题图](images/image_026.png)
![题图](images/image_027.png)
由
![题图](images/image_028.png)
可得:
![题图](images/image_029.png)

**2. 已知某控制系统的微分方程为**
![题图](images/image_030.png)
试列写该系统的状态空间表达式.
答: 由系统微分方程可知系统传递函数为:
![题图](images/image_031.png)
由传递函数可知
![题图](images/image_032.png)
则该系统可控标准型为
![题图](images/image_033.png)
![题图](images/image_034.png)

**3. 某系统状态方程为**
![题图](images/image_035.png)
![题图](images/image_036.png)
(1)判断系统的稳定性.
(2)试讨论通过加入输出反馈, 能否使系统渐进稳定.
(3)试讨论通过加入状态反馈, 能否使系统渐进稳定.
答: (1)系统特征方程
![题图](images/image_037.png)
故系统处于临界稳定状态
(2)由于系统为单输出系统, 设输出反馈矩阵为常数H, 加输出反馈后u=Hy+v, 状态方程变为
![题图](images/image_038.png)
特征方程为
![题图](images/image_039.png)
可知不管H取何值, 均不能使系统特征根均具有负实部, 因此加输出反馈不能使系统渐进稳定.
(3)设u=V+Kx, K=[$k_{1} k_{2}$], 加状态反馈后状态方程为
![题图](images/image_040.png)
特征方程为$λ^{2} - k_{1}$λ+1+ $k_{2} = 0$
通过改变$k_{1}, k_{2}$的值便可以改变系统特征根的值, 可以使系统渐进稳定.

**4. 说明矩阵Φ(t)是否为某系统的状态转移矩阵; 如果是, 请求出其逆阵以及该系统的A阵.**
![题图](images/image_041.png)
答: 根据状态转移矩阵的定义和性质可以判断出, 此矩阵为某一系统的状态转移矩阵
(1)求其逆阵
根据状态转移矩阵的性质有
![题图](images/image_042.png)
(2)求矩阵A
根据状态转移矩阵的性质, Φ(0)=I.
![题图](images/image_043.png)
![题图](images/image_044.png)

**5. 如图2-4-1所示为一摆杆系统, 两摆杆长度均为L, 摆杆质量忽略不计. 摆杆末端的质量块M视为质点, 两摆杆中点处连接了一根弹簧, 当$θ_{1} = θ_{2}$时弹簧没有伸长与压缩. 外力f(t)作用在左杆中点处. 假设摆杆与支点间没有摩擦与阻尼, 而且位移足够小, 满足sinθ=θ, cosθ=1.**
(1)写出系统的运动方程;
(2)写出系统的状态空间表达式.
![题图](images/image_045.png)
图2-4-1
答: (1)对左边质量块有
![题图](images/image_046.png)
对右边质量块有
![题图](images/image_047.png)
因为位移足够小, 满足sinθ=θ, cosθ=1, 可得
![题图](images/image_048.png)
(2)令
![题图](images/image_049.png)
可得系统的状态空间表达式为:
![题图](images/image_050.png)

**6. 请写出如图2-4-2所示电路当开关合上后的系统状态方程与输出方程. 其中状态如图2-4-2所示, 设系统的输出变量为$i_{2}$. 若电路图中所有元件的参数均为1, 试判断系统的可控性与可观性.**
![题图](images/image_051.jpg)
图2-4-2
答: 使用复阻抗法, 可得下面的微分方程:
![题图](images/image_052.png)
得到
![题图](images/image_053.png)
![题图](images/image_054.png)
得到
![题图](images/image_055.png)
![题图](images/image_056.png)
得到
![题图](images/image_057.png)
系统的状态空间表达式如下所示:
![题图](images/image_058.png)
![题图](images/image_059.png)
![题图](images/image_060.png)
![题图](images/image_061.png)
![题图](images/image_062.png)
系统的能控性矩阵为
![题图](images/image_063.png)
rank(P)=3
可知系统可控.
系统的能观性矩阵为
![题图](images/image_064.png)
由于rank(Q)=3, 则系统可观.

**7. 如图2-4-3所示电路网络, $u_{1}$(t)为输入, $u_{0}$(t)为输出.**
(1)写出系统的状态空间表达式;
(2)求系统的传递函数.
![题图](images/image_065.jpg)
图2-4-3
答: (1)选取电容两端电压$u_{c}$和通过电感的电流$i_{L}$. 作为状态变量.
![题图](images/image_066.png)
系统的状态空间表达式为
![题图](images/image_067.png)
![题图](images/image_068.png)
(2)系统的传递函数为
![题图](images/image_069.png)

**8. 已知线性定常系统的传递函数为 ![题图](images/image_070.png) , 写出系统的状态空间表达式, 并使A矩阵为对角矩阵. 当系统的输入作用u(t)=0且初始状态为X(0)=[1 1]^{T}时, 求出系统的输出响应.**
答: 设
![题图](images/image_071.png)
整理可得
![题图](images/image_072.png)
得到
![题图](images/image_073.png)
令状态变量
![题图](images/image_074.png)
![题图](images/image_075.png)
![题图](images/image_076.png)
进行拉普拉斯反变换可得
![题图](images/image_077.png)
![题图](images/image_078.png)
y= $x_{1} + x_{2}$
系统的对角标准型即为
![题图](images/image_079.png)
![题图](images/image_080.png)
![题图](images/image_081.png)
![题图](images/image_082.png)
c=[1 1]
![题图](images/image_083.png)
![题图](images/image_084.png)

**9. 系统微分方程式为 ![题图](images/image_085.png) , 初始条件为零. 求:**
(1)传递函数y(s)/u(s)的表达式.
(2)采用传递函数的并联分解法, 建立系统的状态空间描述表达式.
(3)讨论上述两种表达式的特点.
答: (1)对微分方程两边作零初始条件下的拉普拉斯变换得到
($s^{3} + 5 s^{2}$+7s+3)y(s)=($s^{2}$+6s+8)u(s)
![题图](images/image_086.png)
(2)采用传递函数的并联分解法有
![题图](images/image_087.png)
可得到
![题图](images/image_088.png)
令状态变量
![题图](images/image_089.png)
![题图](images/image_090.png)
![题图](images/image_091.png)
![题图](images/image_092.png)
进行拉普拉斯反变换可得
![题图](images/image_093.png)
可得系统的状态空间表达式为
![题图](images/image_094.png)
![题图](images/image_095.png)
(3)传递函数表达式只是对系统输入、输出的一种描述, 不是对系统结构彻底的、完全的描述, 而状态空间表达式是对系统的完全的描述.

**10. 请列写出如图2-4-4所示的信号流图的状态方程表达式.**
![题图](images/image_096.jpg)
图2-4-4
答: 由系统的信号流图可得
![题图](images/image_097.png)
则系统的状态空间表达式为
![题图](images/image_098.png)
![题图](images/image_099.png)

**11. 给定方阵A, 求$A^{-10000}$和$(e^{A})^{-1}.$**
(1)
![题图](images/image_100.png)
(2)
![题图](images/image_101.png)
答: (1)先求$A^{10000}$
![题图](images/image_102.png)
![题图](images/image_103.png)
![题图](images/image_104.png)
若, 则$A^{n + 1} = A^{n}$A.
![题图](images/image_105.png)
![题图](images/image_106.png)
于是
![题图](images/image_107.png)
令
n=10000
![题图](images/image_108.png)
![题图](images/image_109.png)
A已经是Jordan标准型, 故
![题图](images/image_110.png)
![题图](images/image_111.png)
(2)先求A的特征值, 将A对角化, 由|λE-A|=0有
![题图](images/image_112.png)
得(λ-2)(λ+1)(λ-3)=0, $λ_{2} = - 1, λ_{2} = 2, λ_{3}$=3, 由$Ap_{i} = λ_{i} p_{i}$(i=1, 2, 3), 可得对应的特征向量依次为
$P_{1}$=[-1 1 0]^{T}, $P_{2}$=[0 0 1]^{T}, $P_{3}$=[1 1 0]^{T}, 令
![题图](images/image_113.png)
则
![题图](images/image_114.png)
![题图](images/image_115.png)
![题图](images/image_116.png)
![题图](images/image_117.png)
于是可得
![题图](images/image_118.png)
整理可得
![题图](images/image_119.png)
![题图](images/image_120.png)
整理得到
![题图](images/image_121.png)

**12. 已知线性定常系统的状态空间表达式为**
![题图](images/image_122.png)
y=[1 0 1]x
当系统的初始状态为x(0)=[1 1 1]^{T}时, 求出系统的输出响应.
答: 由题意可得
![题图](images/image_123.png)
c=[1 0 1]
![题图](images/image_124.png)
x(t)= $e^{At}$x(0)
得
![题图](images/image_125.png)
y=[1 0 1]x= $e^{-6t} + e^{-5t}$

**13. 设系统的传递函数为 ![题图](images/image_126.png) , 如果对其施加反馈作用, 有关的变量取为$x_{1}$=y(t), $x_{2}$=y(•)(t), u=-3 $x_{2} - 2 x_{1}$, 试计算该系统的特征根, 并计算初始条件为 ![题图](images/image_127.png) 时, 系统的时间响应函数x(t).**
答: 由题意可得
$s^{2}$Y(s)=U(s)⇒y(••)=u
由$x_{1}$=y(t), $x_{2}$=y(•)(t), u=-3 $x_{2} - 2 x_{1}$, 得到
x $(•)_{1} = x_{2}$
x $(•)_{2}$=y(••)=u=-2 $x_{1} - 3 x_{2}$
因此系统的状态空间表达式为
![题图](images/image_128.png)
![题图](images/image_129.png)
![题图](images/image_130.png)
![题图](images/image_131.png)
系统时间响应函数为
![题图](images/image_132.png)

**14. 某单位输入线性定常系统(也叫线性非时变系统)的状态方程是 ![题图](images/image_133.png) 已知:**
①当时, 系统的零输入响应为;
![题图](images/image_134.png)
![题图](images/image_135.png)
②当时, 系统的零输入响应为;
![题图](images/image_136.png)
![题图](images/image_137.png)
③系统的零状态单位阶跃响应为.
![题图](images/image_138.png)
(1)试确定A和b;
(2)以T=ln2为采样周期, 求系统离散化的状态方程.
答:
(1)系统状态转系矩阵, 则零输入响应, 由条件①②得
![题图](images/image_139.png)
![题图](images/image_140.png)
![题图](images/image_141.png)
解得
![题图](images/image_142.png)
故系统状态矩阵为
![题图](images/image_143.png)
系统状态方程, u(t)=1(t)时单位阶跃响应, 则
![题图](images/image_144.png)
![题图](images/image_145.png)
![题图](images/image_146.png)
解得.
![题图](images/image_147.png)
(2)设离散后的状态空间表达式为x(k+1)=Gx(k)+hu(k), 以T=ln2为采样周期, 则
![题图](images/image_148.png)
![题图](images/image_149.png)
系统离散化的状态方程为
![题图](images/image_150.png)
