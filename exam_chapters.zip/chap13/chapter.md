第五章 矩阵分析

### 一、填空题

**1. 设A=($a_{ij}$)是三阶非零矩阵, |A|为A的行列式, $A_{ij}$为$a_{ij}$的代数余子式, 若$a_{ij} + A_{ij}$=0(i, j=1, 2, 3), 则|A|=______.**
- **答案：** -1
- **解析：** 由已知$a_{ij} + A_{ij}$=0及伴随矩阵的定义可知, $A^{T} = - A^{*}$. 故|A|=|$A^{T}$|=|- $A^{*}$|= $(- 1)^{3}$|$A^{*}$|=-|A|^{2}, 故|A|=0或|A|=-1. 当|A|=0时, $AA^{T}$=|A|^{2}=0⇒A=0, 与A是非零矩阵矛盾, 故|A|=-1.

**2. 设A为3阶矩阵, |A|=3, $A^{*}$为A的伴随矩阵. 若交换A的第1行与第2行得矩阵B, 则|$BA^{*}$|=______.**
- **答案：** -27
- **解析：** 由题意知|B|=-|A|, 而|A*|=|A|^{2}, 故|BA*|=|B|·|A*|=-|A|^{3}=-27.

**3. 设 ![题图](images/image_001.png) , 则$A^{3}$=______.**
- **解析：**
  ![解析图](images/image_002.png)
  因为
  ![解析图](images/image_003.png)
  又因
  ![解析图](images/image_004.png)
  所以$A^{3}$=($αβ^{T}$)($αβ^{T}$)($αβ^{T}$)=α($β^{T}$α)($β^{T}$α)$β^{T} = 4 αβ^{T}$=4A.

**4. 设 ![题图](images/image_005.png) , 则$A^{99}$=______.**
- **解析：**
  ![解析图](images/image_006.png)
  ![解析图](images/image_007.png)
  ![解析图](images/image_008.png)
  从而有
  $A^{5} = A^{3} A^{2}$=2A·$A^{2} = 2 A^{3}$=2^{2}A
  ![解析图](images/image_009.png)

### 二、单项选择题

**1. 设A为三阶矩阵, P为三阶可逆矩阵, 且 ![题图](images/image_010.png) , 若P=($α_{1}, α_{2}, α_{3}$), Q=($α_{1} + α_{2}, α_{2}, α_{3}$), 则$Q^{-1}$AQ=( ).**

- A.![选项图](images/image_011.png)
- B.![选项图](images/image_012.png)
- C.![选项图](images/image_013.png)
- D.![选项图](images/image_014.png)
- **答案：** B
- **解析：**
  ![解析图](images/image_015.png)
  则
  ![解析图](images/image_016.png)
  故
  ![解析图](images/image_017.png)

**2. 若矩阵A经初等列变换化成B, 则( ).**

- A. 存在矩阵P, 使得PA=B
- B. 存在矩阵P, 使得BP=A
- C. 存在矩阵P, 使得PB=A
- D. 方程组Ax=0与Bx=0同解
- **答案：** B
- **解析：**
  ∵A经初等列变换化成B,
  ∴存在可逆矩阵$P_{1}$使得$AP_{1}$=B;
  ∴A= $BP_{1}^{-1}$, 令P= $P_{1}^{-1}$, 则A=BP.
  ∴选B项.

**3. 设A, B是可逆矩阵, 且A与B相似, 则下列结论错误的是( ).**

- A. $A^{T}$与$B^{T}$相似
- B. $A^{-1}$与$B^{-1}$相似
- C. A+ $A^{T}$与B+ $B^{T}$相似
- D. A+ $A^{-1}$与B+ $B^{-1}$相似
- **答案：** C
- **解析：** 因为A和B相似, 所以, 存在可逆矩阵P使得B= $P^{-1}$AP. $B^{T} =(P^{-1}AP)^{T} = P^{T} A^{T}(P^{-1})^{T}$=[$(P^{T})^{-1}$]^{-1}$A^{T}(P^{T})^{-1}$, A项正确; $B^{-1} =(P^{-1}AP)^{-1} = P^{-1} A^{-1}$P, B项正确; B+ $B^{-1} = P^{-1}$AP+ $P^{-1} A^{-1}$P= $P^{-1}$(A+ $A^{-1}$)P, D项正确.

**4. 设$A^{2}$=E, E为单位矩阵, 则以下结论正确的是( ).**

- A. A-E可逆
- B. 当A≠E时, A+E可逆
- C. A+E可逆
- D. 当A≠E时, A+E不可逆
- **答案：** D
- **解析：** 由$A^{2}$=E, 可得(A+E)(A-E)=0. 对等式两边取行列式, 得|A+E||A-E|=0, 若A≠E, 即|A-E|≠0, 有|A+E|=0, 即矩阵A+E不可逆.

**5. A、B、C均为n阶方阵, E为n阶单位矩阵, 且AB=BC=CA=E, 则$A^{2} + B^{2} + C^{2}$=( ).**

- A. 3E
- B. 2E
- C. E
- D. O
- **答案：** A
- **解析：** 由AB=E可知B= $A^{-1}$, 同理知C= $B^{-1}$, A= $C^{-1}$, 故A= $A^{-1}$, B= $B^{-1}$, C= $C^{-1}$. 即.

### 三、计算题与证明题

**1. 设 ![题图](images/image_018.png) , 求3AB-2A及$A^{T}$B.**
解:
![题图](images/image_019.png)
则可得
![题图](images/image_020.png)
因为$A^{T}$=A, 即A为对称阵, 所以可得
![题图](images/image_021.png)

**2. 假设 ![题图](images/image_022.png) , 问:**
(1)AB=BA吗？
(2)$(A + B)^{2} = A^{2}$+2AB+ $B^{2}$吗？
(3)(A+B)(A-B)= $A^{2} - B^{2}$吗？
解: (1)因为
![题图](images/image_023.png)
所以AB≠BA.
(2)$(A + B)^{2}$=(A+B)(A+B)= $A^{2}$+AB+BA+ $B^{2}$, 由(1)可知, AB≠BA, 所以AB+BA≠2AB, 因此$(A + B)^{2}$≠$A^{2}$+2AB+ $B^{2}.$
(3)(A+B)(A-B)= $A^{2}$+BA-AB- $B^{2}$, 但由(1)可知, AB≠BA, 所以BA-AB≠0, 因此(A+B)(A-B)≠$A^{2} - B^{2}.$

**3. 举反例说明下列命题是错误的:**
(1)若$A^{2}$=O, 则A=O;
(2)若$A^{2}$=A, 则A=O或A=E;
(3)若AX=AY, 且A≠O, 则X=Y.
解: (1)取, 则有$A^{2}$=O, 但是A≠O.
![题图](images/image_024.png)
(2)取, 则有$A^{2}$=A, 但是A≠O且A≠E.
![题图](images/image_025.png)
(3)取, 则有AX=AY, 且A≠O, 但是X≠Y.
![题图](images/image_026.png)

**4. (1)设 ![题图](images/image_027.png) , 求$A^{2}, A^{3}$, …, $A^{k};$**
(2)设, 求$A^{4}.$
![题图](images/image_028.png)
解: (1)根据矩阵乘法直接计算可以得到
![题图](images/image_029.png)
![题图](images/image_030.png)
一般可得
(1-5-1)
![题图](images/image_031.png)
则当k=1时, 式(1-5-1)成立.
假设当k=n时, 式(1-5-1)成立, 则当k=n+1时, 则有
![题图](images/image_032.png)
根据数学归纳法可知式(2-2-1)成立.
(2)
![题图](images/image_033.png)
![题图](images/image_034.png)

**5. (1)设 ![题图](images/image_035.png) , 求$A^{50}$和$A^{51};$**
(2)设, A= $ab^{T}$, 求$A^{100}.$
![题图](images/image_036.png)
解: (1)
![题图](images/image_037.png)
则可得
$A^{50} =(A^{2})^{25} =(10E)^{25}$=10^{25}E
![题图](images/image_038.png)
(2)
![题图](images/image_039.png)
由于$b^{T}$a=-8, 所以根据上式可知
![题图](images/image_040.png)

**6. 设 ![题图](images/image_041.png) , AB=A+2B, 求B.**
解: 根据AB=A+2B⇒(A-2E)B=A.
因为, 它的行列式det(A-2E)=2≠0, 所以它是可逆矩阵, 用$(A - 2E)^{-1}$左乘上式两边可得
![题图](images/image_042.png)
![题图](images/image_043.png)

**7. 设 ![题图](images/image_044.png) , 且AB+E= $A^{2}$+B, 求B.**
解: 根据方程AB+E= $A^{2}$+B, 合并含有未知矩阵B的项, 可得
(A-E)B= $A^{2}$-E=(A-E)(A+E)
又因为, 其行列式det(A-E)=-1≠0, 所以A-E可逆, 用$(A - E)^{-1}$左乘上式两边, 即可得到
![题图](images/image_045.png)
![题图](images/image_046.png)

**8. 设矩阵 ![题图](images/image_047.png) , 且$A^{3}$=O.**
(1)求a的值;
(2)若矩阵X满足X- $X^{2}$A-AX+ $AXA^{2}$=E, 其中E为3阶单位矩阵, 求X.
解: (1)由于$A^{3}$=O, 所以
![题图](images/image_048.png)
于是a=0.
(2)由于X- $X^{2}$A-AX+ $AXA^{2}$=E, 所以(E-A)X(E- $A^{2}$)=E.
由(1)知
![题图](images/image_049.png)
因为E-A, E- $A^{2}$均可逆, 所以
![题图](images/image_050.png)

**9. 设B是m×n矩阵, ![题图](images/image_051.png) 可逆, ![题图](images/image_052.png) , 其中E是n阶单位矩阵.**
(Ⅰ)证明: ;
![题图](images/image_053.png)
(Ⅱ)证明: ;
![题图](images/image_054.png)
(Ⅲ)若r(A)=r<n, 且A可对角化, 求行列式.
![题图](images/image_055.png)
解: (Ⅰ)
![题图](images/image_056.png)
(Ⅱ)
![题图](images/image_057.png)
(Ⅲ)设, , 则由, 知, 即λ=0或1. 又存在可逆矩阵P, 使, $λ_{i}$=0或1.
![题图](images/image_058.png)
![题图](images/image_059.png)
![题图](images/image_060.png)
![题图](images/image_061.png)
![题图](images/image_062.png)
由r(A)=r<n知,
![题图](images/image_063.png)
于是
![题图](images/image_064.png)
因此
![题图](images/image_065.png)

**10. 已知$A^{3}$=2E, 且B= $A^{2}$-2A+2E. 求$B^{-1}.$**
解: 由题意知
![题图](images/image_066.png)
故
![题图](images/image_067.png)
又得, , 故.
![题图](images/image_068.png)
![题图](images/image_069.png)
![题图](images/image_070.png)
又
![题图](images/image_071.png)
知
![题图](images/image_072.png)
![题图](images/image_073.png)
知
![题图](images/image_074.png)
即
![题图](images/image_075.png)

**11. 已知 ![题图](images/image_076.png) , 求$A^{100}.$**
解: 令, 则, 且有
![题图](images/image_077.png)
![题图](images/image_078.png)
![题图](images/image_079.png)
所以
![题图](images/image_080.png)

**12. 已知(2E- $C^{-1}$B)$A^{T} = C^{-1}$, 其中E是四阶单位矩阵, $A^{T}$是四阶矩阵A的转置矩阵, ![题图](images/image_081.png) , 求矩阵A.**
解: 对作恒等变形, 有, 即.
![题图](images/image_082.png)
![题图](images/image_083.png)
![题图](images/image_084.png)
由
![题图](images/image_085.png)
故矩阵可逆.
![题图](images/image_086.png)
则有
![题图](images/image_087.png)
以下对矩阵做初等变换求逆,
![题图](images/image_088.png)
所以有
![题图](images/image_089.png)

**13. 设三阶方阵A、B满足$A^{2}$B-A-B=E, 其中E为三阶单位矩阵, 若 ![题图](images/image_090.png) , 求行列式|B|的值.**
解: 由矩阵
![题图](images/image_091.png)
知
![题图](images/image_092.png)
则可逆.
![题图](images/image_093.png)
又
![题图](images/image_094.png)
故
![题图](images/image_095.png)
即
![题图](images/image_096.png)
所以, , 即, 而
![题图](images/image_097.png)
![题图](images/image_098.png)
![题图](images/image_099.png)
故
![题图](images/image_100.png)

**14. 求AB-BA.**
1), ;
![题图](images/image_101.png)
![题图](images/image_102.png)
2), .
![题图](images/image_103.png)
![题图](images/image_104.png)
解: 1)直接由矩阵乘法计算可得
![题图](images/image_105.png)
2)直接由矩阵乘法计算可得
![题图](images/image_106.png)
其中d= $a^{2} + b^{2} + c^{2}$-ab-b-c.

**15. 试求f(A).**
1)f(x)= $x^{2}$-5x+3, ;
![题图](images/image_107.png)
2)f(x)= $x^{2}$-x-1, .
![题图](images/image_108.png)
解: 1)直接运算有
![题图](images/image_109.png)
2)直接运算有
![题图](images/image_110.png)

**16. 若A是可逆方阵, k∈N, 则$A^{k}$也可逆, 且$(A^{k})^{-1} =(A^{-1})^{k}.$**
证明: 对k作归纳证明. 当k=1时, 成立. 设k时成立. 于是
$A^{k + 1}(A^{-1})^{k + 1} = AA^{k}(A^{-1})^{k} A^{-1} = AI_{n} A^{-1} = I_{n}$
因此$A^{k + 1}$可逆, 且$(A^{k + 1})^{-1} =(A^{-1})^{k + 1}.$
注: 从此题可知, 对于可逆方阵A, 可以定义负整数指数幂: $A^{-k} =(A^{-1})^{k}$, ∀k∈N.
此时, 对于∀$k_{1}, k_{2}$∈Z, 有, .
![题图](images/image_111.png)
![题图](images/image_112.png)

**17. A为n阶方阵. 若有k∈N, 使$A^{k}$=0(称为幂零方阵), 则A+ $I_{n}, I_{n}$-A都可逆, 且**
$(I_{n} - A)^{-1} = I_{n}$+A+ $A^{2}$+…+ $A^{k - 1}$
$(I_{n} + A)^{-1} = I_{n}$-A+ $A^{2}$-…+ $(- 1)^{k - 1} A^{k - 1}$
证明: 因为$A^{k}$=0, 于是有
![题图](images/image_113.png)
![题图](images/image_114.png)
所以结论成立.

**18. 设 ![题图](images/image_115.png) , 又A, C为可逆方阵. 求$X^{-1}.$**
解: 设A∈$P^{m×n}$, C∈$P^{n×n}$. 作方阵, $Y_{1}$∈$P^{n×m}, Y_{2}$∈$P^{n×n}, Y_{3}$∈$P^{m×m}, Y_{4}$∈$P^{m×n}$. 于是
![题图](images/image_116.png)
![题图](images/image_117.png)
取$Y_{1} = 0, Y_{4} = 0, Y_{2} = C^{-1}, Y_{3} = A^{-1}$, 得YX= $I_{m + n}$. 故
![题图](images/image_118.png)

**19. 设A, B, C, D∈$P^{n×n}$, 且AC=CA. 试证 ![题图](images/image_119.png) .**
证明: 令A(λ)= $λI_{n}$+A, 则detA(λ)是λ的n次多项式, 至多n个根. 由AC=CA, 有A(λ)C=CA(λ)
若detA(λ)≠0, 则A(λ)可逆, 且有
![题图](images/image_120.png)
于是可得
![题图](images/image_121.png)
由于, det(A(λ)D-CB)都是λ的有限次多项式, 故它们恒等. 特别, 当λ=0时, 也相等, 于是结论成立.
![题图](images/image_122.png)

**20. 设A, B∈$P^{n×n}$. 试证**
![题图](images/image_123.png)
证明: 由
![题图](images/image_124.png)
可得
![题图](images/image_125.png)
